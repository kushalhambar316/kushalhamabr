# Privacy

- This application collects and holds no personal information whatsoever.
- All data purely lives on the installed device only, apart from Android Device backups which will include backups of your notes, which is stored by Google.
- For more information about backups, please see: https://support.google.com/android/answer/2819582
- For details on how backups work: https://developer.android.com/guide/topics/data/autobackup